

function CommingSoon() {
  return (
  <>

    <div className="d-flex justify-content-center align-items-center w-100" style={{height:"80vh"}}>
        <h4 className="border p-2">Team is working on the website... Awaiting for the contents</h4>
    </div>
  </>
  )
}

export default CommingSoon