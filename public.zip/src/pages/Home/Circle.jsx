
import "./circle.css";
const Circle = () => {
  return (
    <>
      <div className="row m-0 mb-3 p-0">
        <div className="col-lg-12 col-md-12 col-12">
          <div className="containerx container bg-white  overFlow">
            <div className="circle pb-5">
              <div className="circle-main">
                <div className="inner-circle">

                  <ul className="sc-fsYfxw fAFqhE">
                    {/* <li className=" circle-item sc-jTQDJr jgULa-d">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" style={{ color: 'rgb(255, 255, 255)' }} />
                      </div>
                    </li> */}
                    <li className=" circle-item sc-jTQDJr cEiyxN">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/1.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr XoRrV">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/2.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr heCKph">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/3.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr eRyzgl">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/4.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr loslBN">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/5.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr iquJLF">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/6.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr fjVtyd">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/7.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr wraFN">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/8.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr fwRtXV">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/9.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className=" circle-item sc-jTQDJr cqsdKt">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/10.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className="sc-jTQDJr item11">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/11.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                    <li className="sc-jTQDJr item12">
                      <div>
                        <button className="sc-beyTiQ qYTGZ" ><img src="images/12.png" alt="" className="img-fluid" /></button>
                      </div>
                    </li>
                  </ul>

                  <div className="inner-circle2">

                    <div className="circle-image">
                      <img src="images/circle.png" className="circle-inner-img" />
                      <img src="images/star.png" className="circle-star" />
                      <img src="images/arrow.png" className="circle-arrow" />

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </>
  );
};

export default Circle;
